# Accounts & MIS Reporting Dashboard – Excel

## Project Overview
This project simulates an entry-level Accounts / MIS Executive workflow for a business operations team. It combines transaction tracking, invoice management, expense monitoring, payment reconciliation, data validation, and monthly MIS reporting in Microsoft Excel.

## Business Problem
Management needs a simple reporting system to answer:
- How much revenue was recorded?
- How much was spent?
- What is the net position?
- Which invoices are still pending?
- What amount is outstanding?
- Which transactions or payments need review?

## Tools Used
- Microsoft Excel / Google Sheets
- Excel formulas: SUM, SUMIF, SUMIFS, COUNTIF, COUNTIFS, IF
- Tables, filters, sorting, conditional formatting
- MIS reporting
- Reconciliation
- Basic charts and dashboarding

## Workbook Sheets
1. **MIS_Dashboard** – KPI summary and management view
2. **Transactions** – transaction-level business data
3. **Invoice_Tracker** – invoice amount, tax, payment and outstanding balance
4. **Expenses** – expense and approval tracker
5. **Reconciliation** – invoice vs payment reconciliation
6. **Monthly_Summary** – monthly revenue, expenses and net position
7. **Formula_Practice** – interview-focused Excel formula examples
8. **Lists** – dropdown/support lists

## Key MIS Outputs
- Total revenue
- Total expenses
- Net position
- Pending invoice count
- Outstanding invoice amount
- Validation review count
- Monthly revenue vs expense trend
- Reconciliation exceptions

## Important Note
All business data in this project is synthetic and created for portfolio / learning purposes. No real company financial data is used.

## GitHub Presentation
Recommended repository name:
`accounts-mis-reporting-dashboard`

Suggested headline:
**Accounts & MIS Reporting Dashboard | Excel | MIS | Reconciliation | Reporting**

Suggested one-line description:
`End-to-end Excel MIS project covering transactions, invoices, expenses, reconciliation, validation, and management reporting.`
