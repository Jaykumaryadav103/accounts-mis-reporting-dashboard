# GitHub Upload Guide – Micro Level

## Step 1: Create the repository
1. Open GitHub and sign in.
2. Click the **+** icon at the top-right.
3. Click **New repository**.
4. Repository name:
   `accounts-mis-reporting-dashboard`
5. Description:
   `Excel MIS project covering transactions, invoices, expenses, reconciliation and management reporting.`
6. Select **Public**.
7. Tick **Add a README file** only if you are creating the repository manually without uploading this project README. If you upload this complete folder, you can leave it unticked.
8. Click **Create repository**.

## Step 2: Download and extract the project
Download the project ZIP from ChatGPT.
Extract it on your computer.
You should see:
- README.md
- dataset
- excel
- dashboard
- documentation

## Step 3: Upload the files
1. Open your new GitHub repository.
2. Click **Add file**.
3. Click **Upload files**.
4. Open the extracted project folder on your computer.
5. Select the project files/folders.
6. Drag them into the GitHub upload area.
7. Scroll down.
8. In the commit message box write:
   `Add Accounts and MIS Reporting Dashboard project`
9. Click **Commit changes**.

## Step 4: Check your repository
Your repository should contain:

accounts-mis-reporting-dashboard/
- README.md
- dataset/transactions.csv
- excel/Accounts_MIS_Report.xlsx
- dashboard/MIS_Dashboard.png
- documentation/Project_Explanation.md
- documentation/Resume_Project_Entry.md

## Step 5: Add it to your resume
Project title:
**Accounts & MIS Reporting Dashboard | Excel**

GitHub description:
**End-to-end Excel MIS project covering transactions, invoice tracking, expenses, payment reconciliation, validation and management reporting.**

## Step 6: Interview explanation
Say:

“I created an Accounts and MIS Reporting Dashboard in Excel. I worked with transaction, invoice and expense data, created separate trackers, performed data validation and reconciliation, and built monthly MIS reports. I used Excel formulas such as SUMIFS, COUNTIFS and IF and created a dashboard for management-level reporting.”

## Important
Do not say that this was a real company project or that you worked for Crossing Infotech. It is a portfolio project created to demonstrate skills relevant to the internship.
