# Resume Project Entry

**Accounts & MIS Reporting Dashboard | Excel**
- Built an end-to-end Excel MIS reporting project covering transactions, invoice tracking, expense management and payment reconciliation.
- Used SUMIFS, COUNTIFS, IF, sorting, filtering, conditional formatting and Excel tables for reporting and data validation.
- Created monthly MIS summaries and a management dashboard to track revenue, expenses, net position, pending invoices and outstanding amounts.
- Designed a reconciliation workflow to identify payment differences and follow-up items.
