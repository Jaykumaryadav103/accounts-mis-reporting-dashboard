# Project Explanation – Interview Ready

## 1. Objective
The objective of this project was to build an Excel-based MIS reporting system that can help an operations/accounts team monitor transactions, invoices, expenses, collections and reconciliation status.

## 2. My Role in the Project
I worked on data organization, validation, reporting logic, invoice tracking, reconciliation and dashboard preparation.

## 3. Data Flow
Raw transaction data -> validation -> invoice and expense tracking -> reconciliation -> monthly summaries -> MIS dashboard.

## 4. Main Work Performed
- Structured transaction-level data in Excel.
- Created an invoice tracker with tax, total invoice, paid amount and outstanding balance.
- Created an expense tracker with department, category, vendor and approval status.
- Built reconciliation logic to compare invoice amounts with payments.
- Created monthly MIS summaries for revenue and expenses.
- Added KPI cards and charts to present the information to management.
- Added data validation and conditional formatting for common operational checks.

## 5. Reconciliation Logic
For each invoice:
Total Invoice = Invoice Amount + Tax Amount
Balance = Total Invoice - Paid Amount
If balance is zero, the invoice is treated as paid/matched.
If a balance remains, the record requires follow-up.

## 6. Interview Answer
**Question: Explain your project.**

Answer:
“I created an Accounts and MIS Reporting Dashboard in Excel to simulate the reporting work of an Accounts or MIS Executive. I used transaction, invoice and expense data and built separate trackers for each process. I used formulas such as SUMIFS, COUNTIFS and IF to calculate monthly revenue, expenses, pending invoices and outstanding balances. I also created a reconciliation sheet to compare invoice amounts with payments and identify differences. Finally, I prepared a dashboard with KPIs and charts so that management can quickly understand the business position.”

## 7. Why This Project Fits the Job
The project directly demonstrates:
- Excel reporting
- MIS preparation
- Data validation
- Invoice tracking
- Expense tracking
- Reconciliation
- Management reporting
- Documentation and record maintenance

## 8. Limitations
This is a portfolio simulation. It does not use real company data and does not represent actual work performed for Crossing Infotech.
